from .methods import methods as Bot
from .message import message as Message
from .tools import tools as Tools

__version__ = '1.8.0'
__author__ = 'Ali Ganji zadeh'
__github__ = 'https://github.com/AliGanji1/pyrubi'
__rubika__ = '@pyrubika'